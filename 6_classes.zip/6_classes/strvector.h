//in case mutliple files in a project include strvector, 
//this instruction says only compile this file once!
#ifndef STRVECTOR_H
#define STRVECTOR_H

#include <string>


class StrVector {
    public:
        //type alias (this is how iterator types work!)

        //define an initial size for your underlying array

        //constructors and destructor


        //public interface: What can users of vectors do with the vector?


        //we will learn how to define operators soon, for now lets make
        //at(index) instead of [index]


        //dont forget about accessing iterators!

    private:
        //all member variables should go here!

        //Any private helper functions we might need?

};





#endif // STRVECTOR_H


