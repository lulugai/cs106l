//include the .h file!
#include "strvector.h"

//constructors
StrVector::StrVector()
{

}

StrVector::StrVector(size_t n, const std::string &val)
{


}

//destructor
StrVector::~StrVector() {

}

size_t StrVector::size() {

}

//interface
bool StrVector::empty() {

}

StrVector::iterator StrVector::begin() {

}


StrVector::iterator StrVector::end() {

} 


std::string& StrVector::at(size_t index) {
    //hint: use your iterator knowledge!

}



void StrVector::insert(size_t pos, const std::string &elem) {
    //what happens if logical_size == array_size?

}


void StrVector::push_back(const std::string &elem) {

}
